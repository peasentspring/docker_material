#!/bin/bash

i=1;
while [ $i -le 200 ]
do
	./mallocBomb -i
done
